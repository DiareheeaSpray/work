# quizGame
Java libGDX quiz game, classic quiz with 4 answers, one correct. Questions from XML file.
